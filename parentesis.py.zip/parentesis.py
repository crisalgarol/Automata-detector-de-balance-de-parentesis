#!/usr/bin/env python
# -*- coding: utf-8 -*- 

import os
import subprocess
import platform
import random
from Tkinter import * #Para evitar el main

def expand(letra, next_symbol):

	if(next_symbol != '(' and next_symbol != ')'):
		return "*"

	if(letra == 'B'):
		if(next_symbol == '('):
			return "(RB"
		else: #Checar esto
			return "^"

	elif(letra == 'R'):
		if(next_symbol == ')'):
			return ")"
		elif(next_symbol == '('):
			return "(RR"

def generar_cadena():

	cad = []
	a = '('
	b = ')'

	for i in range(0, (random.randint(2,15))):

		if(random.randint(0,1)):
			cad.append('(')
		else:
			cad.append(')')

	return str((''.join(cad)))


def evaluar(cadena):


	if(cadena == "" or (cadena[0] != "(" and cadena[0] != ")")):
		print("Cadena no valida")
		return

	derivation_parenthesis = ""
	derivation_letters = "B"

	archivo = open("Historial.txt", "w")

	tam = len(cadena)
	balanceado = False

	print("La evaluación es: \n")
	archivo.write("La evaluación es: \n" )

	print(derivation_letters)
	archivo.write(derivation_letters + "\n")

	for i in range (0, tam):
		
		expanding = expand(derivation_letters[0], cadena[i])

		if(expanding == '*'):
			derivation_letters = ""
			break

		elif(expanding == '^'):
			derivation_letters = ""
			print("Se interrumpió el proceso.")
			archivo.write("Se interrumpió el proceso")
			break;

		auxiliar = ""

		#Quitar paréntesis 

		if(len(expanding) == 1):
			derivation_parenthesis += expanding
			expanding = ""

		elif(expanding != None and expanding[0] == "("):
			for j in expanding:
				if(j == expanding[0]):
					derivation_parenthesis += str(expanding[0])
				else:
					auxiliar += str(j)

			expanding = auxiliar

		#Cambiar valores de R o B

		for k in range(0, len(derivation_letters)):
			if (k == 0):
				auxiliar = expanding
			else:
				auxiliar+=derivation_letters[k]


		derivation_letters = auxiliar
		print(derivation_parenthesis + derivation_letters)
		archivo.write(derivation_parenthesis + derivation_letters + "\n")


	if(derivation_letters == "B"):
		print(derivation_parenthesis)
		archivo.write(derivation_parenthesis)
		archivo.write("\n\nLos paréntesis están balanceados")
		print("Los paréntesis estan balanceados")

	elif (expanding == '*'):
		print("Cadena no valida")

	else:
		print("Los paréntesis NO están balanceados")
		archivo.write(derivation_parenthesis +  derivation_letters)
		archivo.write("\n\nLos paréntesis NO están balanceados\n")
		archivo.write(cadena)

	archivo.close()

def main():
	

	while(True):

		os.system('clear')

		print("		---PROGRAMA DE BALANCEO DE PARÉNTESIS---\n")
		print("\n1) Generar cadena aleatoria y evaluar")
		print("2) Ingresar una cadena")
		print("3) Leer desde archivo")
		print("4) Salir")
		opc = raw_input("--->")


		if(opc == "1"):
			cadena = generar_cadena()
			print("La cadena generada es: " + cadena + "\n\n")
			evaluar(generar_cadena())
			raw_input()

		elif(opc == "2"):
			cadena = raw_input("Ingresa una cadena: ")
			evaluar(cadena)
			raw_input()

		elif (opc == "3"):
			file_name = raw_input("Ingresa el nombre del archivo, no olvides poner la extensión: ")

			try:
				file = open(file_name, "r")
			except:
				raw_input("\nArchivo no encontrado")
				continue

			cadena = file.readline()
			evaluar(cadena)
			raw_input()


		elif (opc == "4"):
			break;

		else:
			raw_input("Opción no valida, inténtelo de nuevo")
			cadena = raw_input("--->")

main()